<?php defined('BASEPATH') OR exit('No direct script access allowed');




$config['encrypt_gue']['encryption_key'] = "mpampam595@@@@";
$config['encrypt_gue']['iv'] = "mpampam595@123";
$config['encrypt_gue']['encryption_mechanism'] = "aes-256-cbc";

//konfigurasi email
$config['email']      = "info@mpampam.com";
$config['password']   = "zzzzz";
$config['smtp_host']  = "ssl://mail.mpampam.com";
$config['smtp_port']  = "465";
