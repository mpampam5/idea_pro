<?php defined('BASEPATH') OR exit('No direct script access allowed');


$config['author'] = "mpampam";


$config['encrypt_gue']['encryption_key'] = "mpampam595@@@@";
$config['encrypt_gue']['iv'] = "mpampam595@123";
$config['encrypt_gue']['encryption_mechanism'] = "aes-256-cbc";
